export default function Footer(){
    return(
        <footer className="footer">
            <div className="wrapper">
                <p>&copy; <a href="#">House Rental System</a>. All rights reserved 2017.</p>
            </div>
        </footer>
    )
}